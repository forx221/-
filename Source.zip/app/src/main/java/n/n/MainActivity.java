package n.n;

import android.app.Activity;
import android.os.Bundle;
import java.io.IOException;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.main);
        initialize(_savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {
    }

    private void initializeLogic() {
        String command = "su";
        java.lang.Process process = null;

        try {
            process = Runtime.getRuntime().exec(command);
            process.waitFor();
        } catch (IOException | InterruptedException e) {
        }
    }

}
